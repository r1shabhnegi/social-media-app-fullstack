export const allowedOrigin = [`https://circlesss.onrender.com`];
